#pragma once

static BOOL WritePrivateProfileInt(LPCSTR lpAppName, LPCSTR lpKeyName, int nInteger, LPCSTR lpFileName) {
    char lpString[1024];
    sprintf(lpString, EX("%d"), nInteger);
    return WritePrivateProfileStringA(lpAppName, lpKeyName, lpString, lpFileName);
}
static BOOL WritePrivateProfileFloat(LPCSTR lpAppName, LPCSTR lpKeyName, float nInteger, LPCSTR lpFileName) {
    char lpString[1024];
    sprintf(lpString, EX("%f"), nInteger);
    return WritePrivateProfileStringA(lpAppName, lpKeyName, lpString, lpFileName);
}
static float GetPrivateProfileFloat(LPCSTR lpAppName, LPCSTR lpKeyName, FLOAT flDefault, LPCSTR lpFileName)
{
    char szData[32];

    GetPrivateProfileStringA(lpAppName, lpKeyName, std::to_string(flDefault).c_str(), szData, 32, lpFileName);

    return (float)atof(szData);
}

static void Save_Settings(LPCSTR path)
{
    WritePrivateProfileInt((EX("Visuals")), (EX("m_playeresp")), visuals::box, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_boxstyle")), visuals::boxMode, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_skeleton")), visuals::skeleton, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_playername")), visuals::name, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_outline")), visuals::outline, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_snaplines")), visuals::lines, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_linemode")), visuals::lineMode, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_debugname")), visuals::weapon, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_ammocount")), visuals::ammo, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_teamid")), visuals::teamid, path);

    WritePrivateProfileInt((EX("Visuals")), (EX("m_item")), visuals::items, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_chest")), visuals::chest, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_ammobox")), visuals::ammobox, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_vehicle")), visuals::vehicle, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_supply")), visuals::supply, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_common")), items::Common, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_uncommon")), items::UnCommon, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_purple")), items::purple, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_rare")), items::rare, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_mythic")), items::mythic, path);
    WritePrivateProfileInt((EX("Visuals")), (EX("m_gold")), items::gold, path);

    WritePrivateProfileInt((EX("Aimbot")), (EX("m_aimbot")), aimbot::aimbot, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_smooth")), aimbot::smooth, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotfov")), aimbot::aimfov, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_adsfov")), aimbot::adsfov, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotsmooth")), aimbot::aimspeed, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_hipfirespeed")), aimbot::hipfire, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_fovcircle")), aimbot::fovcircle, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_aimkey")), hotkeys::aimkey, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_hitbox")), aimbot::hitbox, path);

    WritePrivateProfileInt((EX("Aimbot")), (EX("m_aimbot2")), aimbot2::aimbot, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_smooth2")), aimbot2::smooth, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotfov2")), aimbot2::aimfov, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_adsfov2")), aimbot2::adsfov, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotsmooth2")), aimbot2::aimspeed, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_hipfirespeed2")), aimbot2::hipfire, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_fovcircle2")), aimbot2::fovcircle, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_aimkey2")), hotkeys2::aimkey2, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_hitbox2")), aimbot2::hitbox, path);

    WritePrivateProfileInt((EX("Aimbot")), (EX("m_aimbot3")), aimbot3::aimbot, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_smooth3")), aimbot3::smooth, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotfov3")), aimbot3::aimfov, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_adsfov3")), aimbot3::adsfov, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotsmooth3")), aimbot3::aimspeed, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_hipfirespeed3")), aimbot3::hipfire, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_fovcircle3")), aimbot3::fovcircle, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_aimkey3")), hotkeys3::aimkey3, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_hitbox3")), aimbot3::hitbox, path);

    WritePrivateProfileInt((EX("Aimbot")), (EX("m_aimbot4")), aimbot4::aimbot, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_smooth4")), aimbot4::smooth, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotfov4")), aimbot4::aimfov, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_adsfov4")), aimbot4::adsfov, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotsmooth4")), aimbot4::aimspeed, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_hipfirespeed4")), aimbot4::hipfire, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_fovcircle4")), aimbot4::fovcircle, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_aimkey4")), hotkeys4::aimkey4, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_hitbox4")), aimbot4::hitbox, path);

    WritePrivateProfileInt((EX("Aimbot")), (EX("m_aimbot5")), aimbot5::aimbot, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_smooth5")), aimbot5::smooth, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotfov5")), aimbot5::aimfov, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_adsfov5")), aimbot5::adsfov, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotsmooth5")), aimbot5::aimspeed, path);
    WritePrivateProfileFloat((EX("Aimbot")), (EX("m_hipfirespeed5")), aimbot5::hipfire, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_fovcircle5")), aimbot5::fovcircle, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_aimkey5")), hotkeys5::aimkey5, path);
    WritePrivateProfileInt((EX("Aimbot")), (EX("m_hitbox5")), aimbot5::hitbox, path);

    WritePrivateProfileFloat((EX("Colors")), (EX("m_invir")), colors::invisible[0], path);
    WritePrivateProfileFloat((EX("Colors")), (EX("m_invig")), colors::invisible[1], path);
    WritePrivateProfileFloat((EX("Colors")), (EX("m_invib")), colors::invisible[2], path);
    WritePrivateProfileFloat((EX("Colors")), (EX("m_visibr")), colors::visible[0], path);
    WritePrivateProfileFloat((EX("Colors")), (EX("m_visibg")), colors::visible[1], path);
    WritePrivateProfileFloat((EX("Colors")), (EX("m_visibb")), colors::visible[2], path);
    WritePrivateProfileFloat((EX("Colors")), (EX("m_fovr")), colors::fov[0], path);
    WritePrivateProfileFloat((EX("Colors")), (EX("m_fovg")), colors::fov[1], path);
    WritePrivateProfileFloat((EX("Colors")), (EX("m_fovb")), colors::fov[2], path);

    WritePrivateProfileInt((EX("Distance")), (EX("m_playerdistance")), visuals::MaxDistance, path);
    WritePrivateProfileInt((EX("Distance")), (EX("m_esqueletoistance")), visuals::MaxSkeletonDrawDistance, path);
    WritePrivateProfileInt((EX("Distance")), (EX("m_itemdistance")), visuals::ItemDistance, path);
    WritePrivateProfileInt((EX("Distance")), (EX("m_chestdistance")), visuals::ChestDistance, path);
    WritePrivateProfileInt((EX("Distance")), (EX("m_ammoboxdistance")), visuals::AmmoDistance, path);
    WritePrivateProfileInt((EX("Distance")), (EX("m_vehiceldistance")), visuals::VehicleDistance, path);
    WritePrivateProfileInt((EX("Distance")), (EX("m_supplydistance")), visuals::SupplyDistance, path);

    WritePrivateProfileInt((EX("Distance")), (EX("m_aimbotdistance")), aimbot::aimdistance, path);
    WritePrivateProfileInt((EX("Distance")), (EX("m_aimbotdistance2")), aimbot2::aimdistance, path);
    WritePrivateProfileInt((EX("Distance")), (EX("m_aimbotdistance3")), aimbot3::aimdistance, path);
    WritePrivateProfileInt((EX("Distance")), (EX("m_aimbotdistance4")), aimbot4::aimdistance, path);
    WritePrivateProfileInt((EX("Distance")), (EX("m_aimbotdistance5")), aimbot4::aimdistance, path);
}
static void Load_Settings(LPCSTR path)
{
    visuals::box = GetPrivateProfileIntA((EX("Visuals")), (EX("m_playeresp")), visuals::box, path);
    visuals::radar = GetPrivateProfileIntA((EX("Visuals")), (EX("m_radar")), visuals::radar, path);
    visuals::boxMode = GetPrivateProfileIntA((EX("Visuals")), (EX("m_boxstyle")), visuals::boxMode, path);
    visuals::skeleton = GetPrivateProfileIntA((EX("Visuals")), (EX("m_skeleton")), visuals::skeleton, path);
    visuals::name = GetPrivateProfileIntA((EX("Visuals")), (EX("m_playername")), visuals::name, path);
    visuals::outline = GetPrivateProfileIntA((EX("Visuals")), (EX("m_outline")), visuals::outline, path);
    visuals::lines = GetPrivateProfileIntA((EX("Visuals")), (EX("m_snaplines")), visuals::lines, path);
    visuals::lineMode = GetPrivateProfileIntA((EX("Visuals")), (EX("m_linemode")), visuals::lineMode, path);
    visuals::weapon = GetPrivateProfileIntA((EX("Visuals")), (EX("m_debugname")), visuals::weapon, path);
    visuals::ammo = GetPrivateProfileIntA((EX("Visuals")), (EX("m_ammocount")), visuals::ammo, path);
    visuals::teamid = GetPrivateProfileIntA((EX("Visuals")), (EX("m_teamid")), visuals::teamid, path);

    visuals::items = GetPrivateProfileIntA((EX("Visuals")), (EX("m_item")), visuals::items, path);
    visuals::chest = GetPrivateProfileIntA((EX("Visuals")), (EX("m_chest")), visuals::chest, path);
    visuals::ammobox = GetPrivateProfileIntA((EX("Visuals")), (EX("m_ammobox")), visuals::ammobox, path);
    visuals::vehicle = GetPrivateProfileIntA((EX("Visuals")), (EX("m_vehicle")), visuals::vehicle, path);
    visuals::supply = GetPrivateProfileIntA((EX("Visuals")), (EX("m_supply")), visuals::supply, path);
    items::Common = GetPrivateProfileIntA((EX("Visuals")), (EX("m_common")), items::Common, path);
    items::UnCommon = GetPrivateProfileIntA((EX("Visuals")), (EX("m_uncommon")), items::UnCommon, path);
    items::purple = GetPrivateProfileIntA((EX("Visuals")), (EX("m_purple")), items::purple, path);
    items::rare = GetPrivateProfileIntA((EX("Visuals")), (EX("m_rare")), items::rare, path);
    items::mythic = GetPrivateProfileIntA((EX("Visuals")), (EX("m_mythic")), items::mythic, path);
    items::gold = GetPrivateProfileIntA((EX("Visuals")), (EX("m_gold")), items::gold, path);

    aimbot::aimbot = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_aimbot")), aimbot::aimbot, path);
    aimbot::smooth = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_smooth")), aimbot::smooth, path);
    aimbot::aimfov = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotfov")), aimbot::aimfov, path);
    aimbot::adsfov = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_adsfov")), aimbot::adsfov, path);
    aimbot::aimspeed = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotsmooth")), aimbot::aimspeed, path);
    aimbot::hipfire = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_hipfirespeed")), aimbot::hipfire, path);
    aimbot::fovcircle = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_fovcircle")), aimbot::fovcircle, path);
    hotkeys::aimkey = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_aimkey")), hotkeys::aimkey, path);
    aimbot::hitbox = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_hitbox")), aimbot::hitbox, path);

    aimbot2::aimbot = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_aimbot2")), aimbot2::aimbot, path);
    aimbot2::smooth = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_smooth2")), aimbot2::smooth, path);
    aimbot2::aimfov = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotfov2")), aimbot2::aimfov, path);
    aimbot2::adsfov = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_adsfov2")), aimbot2::adsfov, path);
    aimbot2::aimspeed = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotsmooth2")), aimbot2::aimspeed, path);
    aimbot2::hipfire = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_hipfirespeed2")), aimbot2::hipfire, path);
    aimbot2::fovcircle = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_fovcircle2")), aimbot2::fovcircle, path);
    hotkeys2::aimkey2 = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_aimkey2")), hotkeys2::aimkey2, path);
    aimbot2::hitbox = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_hitbox2")), aimbot2::hitbox, path);

    aimbot3::aimbot = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_aimbot3")), aimbot3::aimbot, path);
    aimbot3::smooth = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_smooth3")), aimbot3::smooth, path);
    aimbot3::aimfov = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotfov3")), aimbot3::aimfov, path);
    aimbot3::adsfov = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_adsfov3")), aimbot3::adsfov, path);
    aimbot3::aimspeed = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotsmooth3")), aimbot3::aimspeed, path);
    aimbot3::hipfire = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_hipfirespeed3")), aimbot3::hipfire, path);
    aimbot3::fovcircle = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_fovcircle3")), aimbot3::fovcircle, path);
    hotkeys3::aimkey3 = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_aimkey3")), hotkeys3::aimkey3, path);
    aimbot3::hitbox = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_hitbox3")), aimbot3::hitbox, path);

    aimbot4::aimbot = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_aimbot4")), aimbot4::aimbot, path);
    aimbot4::smooth = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_smooth4")), aimbot4::smooth, path);
    aimbot4::aimfov = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotfov4")), aimbot4::aimfov, path);
    aimbot4::adsfov = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_adsfov4")), aimbot4::adsfov, path);
    aimbot4::aimspeed = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotsmooth4")), aimbot4::aimspeed, path);
    aimbot4::hipfire = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_hipfirespeed4")), aimbot4::hipfire, path);
    aimbot4::fovcircle = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_fovcircle4")), aimbot4::fovcircle, path);
    hotkeys4::aimkey4 = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_aimkey4")), hotkeys4::aimkey4, path);
    aimbot4::hitbox = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_hitbox4")), aimbot4::hitbox, path);

    aimbot5::aimbot = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_aimbot5")), aimbot5::aimbot, path);
    aimbot5::smooth = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_smooth5")), aimbot5::smooth, path);
    aimbot5::aimfov = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotfov5")), aimbot5::aimfov, path);
    aimbot5::adsfov = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_adsfov5")), aimbot5::adsfov, path);
    aimbot5::aimspeed = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_aimbotsmooth5")), aimbot5::aimspeed, path);
    aimbot5::hipfire = GetPrivateProfileFloat((EX("Aimbot")), (EX("m_hipfirespeed5")), aimbot5::hipfire, path);
    aimbot5::fovcircle = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_fovcircle5")), aimbot5::fovcircle, path);
    hotkeys5::aimkey5 = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_aimkey5")), hotkeys5::aimkey5, path);
    aimbot5::hitbox = GetPrivateProfileIntA((EX("Aimbot")), (EX("m_hitbox5")), aimbot5::hitbox, path);

    colors::invisible[0] = GetPrivateProfileFloat((EX("Colors")), (EX("m_invir")), colors::invisible[0], path);
    colors::invisible[1] = GetPrivateProfileFloat((EX("Colors")), (EX("m_invig")), colors::invisible[1], path);
    colors::invisible[2] = GetPrivateProfileFloat((EX("Colors")), (EX("m_invib")), colors::invisible[2], path);
    colors::visible[0] = GetPrivateProfileFloat((EX("Colors")), (EX("m_visibr")), colors::visible[0], path);
    colors::visible[1] = GetPrivateProfileFloat((EX("Colors")), (EX("m_visibg")), colors::visible[1], path);
    colors::visible[2] = GetPrivateProfileFloat((EX("Colors")), (EX("m_visibb")), colors::visible[2], path);
    colors::fov[0] = GetPrivateProfileFloat((EX("Colors")), (EX("m_fovr")), colors::fov[0], path);
    colors::fov[1] = GetPrivateProfileFloat((EX("Colors")), (EX("m_fovg")), colors::fov[1], path);
    colors::fov[2] = GetPrivateProfileFloat((EX("Colors")), (EX("m_fovb")), colors::fov[2], path);

    visuals::MaxDistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_playerdistance")), visuals::MaxDistance, path);
    visuals::MaxSkeletonDrawDistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_esqueletoistance")), visuals::MaxSkeletonDrawDistance, path);
    visuals::ItemDistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_itemdistance")), visuals::ItemDistance, path);
    visuals::ChestDistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_chestdistance")), visuals::ChestDistance, path);
    visuals::AmmoDistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_ammoboxdistance")), visuals::AmmoDistance, path);
    visuals::VehicleDistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_vehiceldistance")), visuals::VehicleDistance, path);
    visuals::SupplyDistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_supplydistance")), visuals::SupplyDistance, path);

    aimbot::aimdistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_aimbotdistance")), aimbot::aimdistance, path);
    aimbot2::aimdistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_aimbotdistance2")), aimbot2::aimdistance, path);
    aimbot3::aimdistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_aimbotdistance3")), aimbot3::aimdistance, path);
    aimbot4::aimdistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_aimbotdistance4")), aimbot4::aimdistance, path);
    aimbot5::aimdistance = GetPrivateProfileIntA((EX("Distance")), (EX("m_aimbotdistance5")), aimbot5::aimdistance, path);
};