#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <Windows.h>
#include <TlHelp32.h>
#include <iostream>
#include <algorithm>
#include <xmmintrin.h>
#include <emmintrin.h>

#include <dwmapi.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <mutex>
#include <vector>
#include <atomic>
#include <thread>
#include <chrono>
#include <random>
#include <stdio.h>
#include <string.h>
#include <cstdlib>
#include <algorithm>
#include <tchar.h>

#include <d3d9.h>
#include <d3dx9.h>
#include <d3d11.h>
#include <dxgi.h>
#include <Dwmapi.h>

#include "Imgui/imgui.h"
#include "Imgui/imgui_impl_dx11.h"
#include "Imgui/imgui_impl_win32.h"

#pragma comment(lib, "Dwmapi.lib")
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "d3d9")

using namespace std;

#include "IDA.h"
#include "crypt.h"
#include "mouse.h"
#include "vars.h"
#include "comms.h"
#include "vector.h"
#include "render.h"
#include "config.h"
#include "offests.h"
#include "esp.h"
#include "WindowHijack.h"
#include "overlay.h"
