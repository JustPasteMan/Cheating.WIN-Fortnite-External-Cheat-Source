#include "stdafx.h"

auto main() -> int {

	if (!InitHandles()) {
		printf(EX("[mapper] Driver is not loaded properly!\n"));
		return -1;
	}

	if (!MouseController::Init()) {
		printf(EX("[mapper] failed\n"));
		return -1;
	}

	globals::UsermodepID = GetCurrentProcessId();
	if (!globals::UsermodepID) {
		printf(EX("[mapper] usermode PID not found!\n"));
	}
	printf("UserMode ID -> %d\n", globals::UsermodepID);

	globals::ProcID = GetAowProcId();
	if (!globals::ProcID) {
		printf(EX("[mapper] process not found!\n"));
	}
	printf(EX("Process ID -> %d\n"), globals::ProcID);

	globals::imagebase = GetBaseAddress();
	if (!globals::imagebase) {
		printf(EX("[mapper] failed to get base address of process id -> %d\n"), globals::ProcID);
	}

	printf(EX("Image Base -> 0x%llX\n"), globals::imagebase);

	SetupWindow();
	DirectXInit(MyWnd);

	_beginthread(LootCache1, 0, nullptr);
	_beginthread(LootCache2, 0, nullptr);
	_beginthread(EntityCache, 0, nullptr);

	MainLoop();
}