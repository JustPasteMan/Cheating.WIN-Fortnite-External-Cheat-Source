#pragma once

typedef struct _MEMORY_STRUCT
{
	BYTE type;
	LONG usermode_pid;
	LONG target_pid;
	ULONG64 base_address;
	void* address;
	LONG size;
	void* output;
	ULONG magic;

	uint32_t value;
	uint64_t window_handle;
}MEMORY_STRUCT;

NTSTATUS(*NtUserMessageCall)(HWND hWnd, UINT msg, PVOID wParam, PVOID lParam, ULONG_PTR ResultInfo, DWORD dwType, BOOLEAN bAnsi) = nullptr;
HWND ValidHwnd;
UINT MsgKey;

bool InitHandles() {
	LoadLibraryA(EX("user32.dll"));
	LoadLibraryA(EX("win32u.dll"));
	LoadLibraryA(EX("ntdll.dll"));

	*(PVOID*)&NtUserMessageCall = GetProcAddress(
		GetModuleHandleA(EX("win32u.dll")),
		EX("NtUserMessageCall")
	);
	if (!NtUserMessageCall)
		return false;

	srand(GetTickCount64() * GetCurrentProcessId() * GetCurrentThreadId());
	MsgKey = 0xbd4 + (rand() % 0x1ffff);

	ValidHwnd = FindWindowA(EX("WorkerW"), 0);
	if (INVALID_HANDLE_VALUE != ValidHwnd)
		return true;
	return false;
}

int GetProcessThreadNumByID(DWORD dwPID)
{
	HANDLE hProcessSnap = ::CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (hProcessSnap == INVALID_HANDLE_VALUE)
		return 0;

	PROCESSENTRY32 pe32 = { 0 };
	pe32.dwSize = sizeof(pe32);
	BOOL bRet = ::Process32First(hProcessSnap, &pe32);;
	while (bRet)
	{
		if (pe32.th32ProcessID == dwPID)
		{
			::CloseHandle(hProcessSnap);
			return pe32.cntThreads;
		}
		bRet = ::Process32Next(hProcessSnap, &pe32);
	}
	return 0;
}

int GetAowProcId()
{
	DWORD dwRet = 0;
	DWORD dwThreadCountMax = 0;
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	PROCESSENTRY32 pe32;
	pe32.dwSize = sizeof(PROCESSENTRY32);
	Process32First(hSnapshot, &pe32);
	do
	{
		if (_tcsicmp(pe32.szExeFile, EX("FortniteClient-Win64-Shipping.exe")) == 0)

		{
			DWORD dwTmpThreadCount = GetProcessThreadNumByID(pe32.th32ProcessID);

			if (dwTmpThreadCount > dwThreadCountMax)
			{
				dwThreadCountMax = dwTmpThreadCount;
				dwRet = pe32.th32ProcessID;
			}
		}
	} while (Process32Next(hSnapshot, &pe32));
	CloseHandle(hSnapshot);
	return dwRet;
}

NTSTATUS change_protect_window_ex(HWND window_handle, uint32_t value)
{
	MEMORY_STRUCT memory_struct = { 0 };
	memory_struct.type = 4;
	memory_struct.window_handle = reinterpret_cast<uint64_t>(window_handle);
	memory_struct.value = value;

	return NtUserMessageCall(ValidHwnd, MsgKey, &memory_struct, 0, 0xDEAD420, 16, 0);
}
static DWORD64 GetBaseAddress()
{
	MEMORY_STRUCT memory_struct = { 0 };
	memory_struct.type = 17;
	memory_struct.usermode_pid = globals::ProcID;

	NtUserMessageCall(ValidHwnd, MsgKey, &memory_struct, 0, 0xDEAD420, 16, 0);
	return memory_struct.base_address;
}
template <typename T>
T read(uintptr_t address)
{
	T buffer{ };
	MEMORY_STRUCT memory_struct = { 0 };
	memory_struct.type = 2;
	//memory_struct.usermode_pid = globals::UsermodepID;
	memory_struct.target_pid = globals::ProcID;
	memory_struct.address = reinterpret_cast<void*>(address);
	memory_struct.output = &buffer;
	memory_struct.size = sizeof(T);

	NtUserMessageCall(ValidHwnd, MsgKey, &memory_struct, 0, 0xDEAD420, 16, 0);
	return buffer;
}
static NTSTATUS ReadProcessMemory(uint64_t src, void* dest, uint32_t size)
{
	MEMORY_STRUCT memory_struct = { 0 };
	memory_struct.type = 2;
	//memory_struct.usermode_pid = globals::UsermodepID;
	memory_struct.target_pid = globals::ProcID;
	memory_struct.address = reinterpret_cast<void*>(src);
	memory_struct.output = dest;
	memory_struct.size = size;

	return NtUserMessageCall(ValidHwnd, MsgKey, &memory_struct, 0, 0xDEAD420, 16, 0);
}
static std::string readwtf(uintptr_t Address, void* Buffer, SIZE_T Size)
{
	ReadProcessMemory(Address, Buffer, Size);

	char name[255] = { 0 };
	memcpy(&name, Buffer, Size);

	return std::string(name);
}
template<typename T>
bool write(uint64_t address, T buffer)
{
	MEMORY_STRUCT memory_struct = { 0 };
	memory_struct.type = 1;
	//memory_struct.usermode_pid = globals::UsermodepID;
	memory_struct.target_pid = globals::ProcID;
	memory_struct.address = reinterpret_cast<void*>(address);
	memory_struct.size = sizeof(T);
	memory_struct.output = &buffer;
	NtUserMessageCall(ValidHwnd, MsgKey, &memory_struct, 0, 0xDEAD420, 16, 0);
	return true;
}