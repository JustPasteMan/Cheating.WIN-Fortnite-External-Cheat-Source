#pragma once

static float closestDistance = FLT_MAX;
static DWORD_PTR closestPawn = NULL;
static bool targetlocked = false;
static bool isaimbotting;

namespace globals
{
    static int32_t ProcID;
    static int64_t imagebase;
    static int32_t UsermodepID;
    static int64_t peb;

    static DWORD ScreenCenterX = NULL;
    static DWORD ScreenCenterY = NULL;

    static int width, height;
}
namespace aimbot
{
    static bool aimbot = false;
    static bool smooth = false;
    static bool fovcircle = false;
    static bool prediction = false;

   static float aimspeed = 5.f;
    static float hipfire = 13.f;
    static float aimfov = 300.f;
    static float aimdistance = 300.f;
    static float lock = 0.f;
    static float adsfov = 300.f;

    static int hitbox = 0;
}
namespace aimbot2
{
    static bool aimbot = false;
    static bool smooth = false;
    static bool fovcircle = false;
    static bool prediction = false;

   static float aimspeed = 5.f;
    static float hipfire = 7.f;
    static float aimfov = 250.f;
     static float aimdistance = 300.f;
    static float lock = 0.f;
    static float adsfov = 300.f;

    static int hitbox = 0;
}
namespace aimbot3
{
    static bool aimbot = false;
    static bool smooth = false;
    static bool fovcircle = false;
    static bool prediction = false;

   static float aimspeed = 5.f;
    static float hipfire = 8.f;
    static float aimfov = 300.f;
     static float aimdistance = 300.f;
    static float lock = 0.f;
    static float adsfov = 350.f;

    static int hitbox = 0;
}
namespace aimbot4
{
    static bool aimbot = false;
    static bool smooth = false;
    static bool fovcircle = false;
    static bool prediction = false;

   static float aimspeed = 5.f;
    static float hipfire = 10.f;
    static float aimfov = 220.f;
     static float aimdistance = 300.f;
    static float lock = 0.f;
    static float adsfov = 300.f;

    static int hitbox = 0;
}
namespace aimbot5
{
    static bool aimbot = false;
    static bool smooth = false;
    static bool fovcircle = false;
    static bool prediction = false;

    static float aimspeed = 5.f;
    static float hipfire = 7.f;
    static float aimfov = 350.f;
     static float aimdistance = 300.f;
    static float lock = 0.f;
    static float adsfov = 400.f;

    static int hitbox = 0;
}
namespace hotkeys
{
    static int aimkey = 0;
}
namespace hotkeys2
{
    static int aimkey2 = 0;
}
namespace hotkeys3
{
    static int aimkey3 = 0;
}
namespace hotkeys4
{
    static int aimkey4 = 0;
}
namespace hotkeys5
{
    static int aimkey5 = 0;
}
namespace visuals
{
    static bool box = false;
    static bool skeleton = false;
    static bool name = false;
    static bool supply = false;

    static bool ammo = false;
    static bool teamid = false;
    static bool weapon = false;
    static bool ammobox = false;


    static bool lines = false;
    static bool outline = false;
    static bool radar = false;
    static bool distance = false;
    static bool vehicle = false;
    static bool items = false;
    static bool chest = false;

    static int boxMode = 0;
    static int skelMode = 0;
    static int lineMode = 0;
    static int radarstyle = 0;

    static float MaxSkeletonDrawDistance = 50.f;
    static float MaxDistance = 150.f;
    static float ItemDistance = 50.f;
    static float ChestDistance = 50.f;
    static float SupplyDistance = 50.f;
    static float AmmoDistance = 50.f;
    static float VehicleDistance = 50.f;

    static bool smg = 0;
    static bool rifle = 0;
    static bool shotgun;
}
namespace thickness {

    static int SkeletonThick = 1;
    static int box_thick = 1;
}
namespace colors {

    static float invisible[3] = { 1.0f , 0.0f , 0.0f };
    static float visible[3] = { 1.0f , 0.0f , 0.0f };
    static float fov[3] = { 1.0f , 0.0f , 0.0f };
}
namespace setting {

    static int settsMode = 0;
}
namespace items {

    static bool Common = false;
    static bool UnCommon = false;
    static bool rare = false;
    static bool purple = false;
    static bool gold = false;
    static bool mythic;
}

static const char* settsName[] =
{
    "Default",
    "Fn-Default1",
    "Fn-Default2"
};
static const char* RadarStyle[] =
{
    "Box",
    "Box Filled",
    "Circle",
    "Circle Filled"
};
static const char* Hitbox[] =
{
    "Head",
    "Neck",
    "Pelvis"
};
static const char* boxStyle[] =
{
    "2D",
    "2D Filled",
    "2D Corner",
    "2D Corner Filled",
};
static const char* linesMode[] =
{
    "Bottom",
    "Top",
    "Center"
};
static DWORD select_hitbox()
{
    static DWORD hitbox = 0;

    if (aimbot::hitbox == 0)
        hitbox = 68;
    else if (aimbot::hitbox == 1)
        hitbox = 67;
    else if (aimbot::hitbox == 2)
        hitbox = 2;
    return hitbox;
}