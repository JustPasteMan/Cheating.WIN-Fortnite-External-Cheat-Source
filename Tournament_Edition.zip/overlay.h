﻿#pragma once

RECT GameRect;
MARGINS Margin = { -1 };
RECT rc2;

ID3D11Device* g_pd3dDevice;
ID3D11DeviceContext* g_pd3dDeviceContext;
IDXGISwapChain* g_pSwapChain;
ID3D11RenderTargetView* g_mainRenderTargetView;

HWND GameWnd;
HWND MyWnd;
WNDCLASSEX wClass;

MSG Message = { NULL };

ImFont* SkeetFont;

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
void CreateRenderTarget()
{
	ID3D11Texture2D* pBackBuffer;
	g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
	g_pd3dDevice->CreateRenderTargetView(pBackBuffer, NULL, &g_mainRenderTargetView);
	pBackBuffer->Release();
}
void CleanupRenderTarget()
{
	if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = NULL; }
}
void CleanupDeviceD3D()
{
	CleanupRenderTarget();
	if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = NULL; }
	if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = NULL; }
	if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = NULL; }
}
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
		return true;

	switch (msg)
	{
	case WM_SIZE:
		if (g_pd3dDevice != NULL && wParam != SIZE_MINIMIZED)
		{
			CleanupRenderTarget();
			g_pSwapChain->ResizeBuffers(0, (UINT)LOWORD(lParam), (UINT)HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
			CreateRenderTarget();
		}
		return 0;
	case WM_SYSCOMMAND:
		if ((wParam & 0xfff0) == SC_KEYMENU) // Disable ALT application menu
			return 0;
		break;
	case WM_DESTROY:
		::PostQuitMessage(0);
		return 0;
	}
	return ::DefWindowProc(hWnd, msg, wParam, lParam);
}
HRESULT DirectXInit(HWND hWnd)
{
	DXGI_SWAP_CHAIN_DESC SwapChainDesc;
	ZeroMemory(&SwapChainDesc, sizeof(DXGI_SWAP_CHAIN_DESC));
	SwapChainDesc.Windowed = TRUE;
	SwapChainDesc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
	SwapChainDesc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	SwapChainDesc.BufferDesc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;
	SwapChainDesc.BufferDesc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
	SwapChainDesc.BufferDesc.RefreshRate.Numerator = 60;
	SwapChainDesc.BufferDesc.RefreshRate.Denominator = 1;
	SwapChainDesc.BufferDesc.Height = 0;
	SwapChainDesc.BufferDesc.Width = 0;
	SwapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	SwapChainDesc.BufferCount = 1;
	SwapChainDesc.OutputWindow = MyWnd;
	SwapChainDesc.SampleDesc.Count = 8;
	SwapChainDesc.SampleDesc.Quality = 0;

	UINT createDeviceFlags = 0;
	D3D_FEATURE_LEVEL featureLevel;
	const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
	if (D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &SwapChainDesc, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext) != S_OK)
		return false;

	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO(); (void)io;

	auto& style = ImGui::GetStyle();
	style.FrameBorderSize = 1.f;
	style.FrameRounding = 0.f;
	style.FramePadding = ImVec2(4.f, 0.f);
	style.GrabRounding = 3.f;
	style.TabRounding = 0.f;
	style.TabBorderSize = 1.f;
	style.ScrollbarSize = 3.f;
	style.WindowTitleAlign.x = 0.50f;

	ImFont* Verdana = io.Fonts->AddFontFromFileTTF(EX("C:\\Windows\\Fonts\\Verdana.ttf"), 15.0f);
	io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange;

	ID3D11Texture2D* pBackBuffer;
	g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
	g_pd3dDevice->CreateRenderTargetView(pBackBuffer, NULL, &g_mainRenderTargetView);

	ImGui_ImplWin32_Init(MyWnd);
	ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

	pBackBuffer->Release();

	SetWindowPos(MyWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
}
bool SetupWindow()
{
	while (!MyWnd) {
		MyWnd = SetUp::HiJackNotepadWindow();
		Sleep(100);
	}

	MARGINS margin = { -1 };
	DwmExtendFrameIntoClientArea(MyWnd, &margin);
	SetMenu(MyWnd, NULL);
	SetWindowLongPtr(MyWnd, GWL_STYLE, WS_VISIBLE);
	SetWindowLongPtr(MyWnd, GWL_EXSTYLE, WS_EX_LAYERED | WS_EX_TRANSPARENT);

	ShowWindow(MyWnd, SW_SHOW);
	UpdateWindow(MyWnd);

	SetWindowLong(MyWnd, GWL_EXSTYLE, GetWindowLong(MyWnd, GWL_EXSTYLE) | WS_EX_LAYERED | WS_EX_TRANSPARENT);

	return true;
}

static auto menu() -> void
{
	static int MenuTab = 0;
	static int VisualTab = 0;

	static auto flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar;

	ImGuiStyle* style = &ImGui::GetStyle();

	float
		TextSpaceLine = 90.f,
		SpaceLineOne = 120.f,
		SpaceLineTwo = 280.f,
		SpaceLineThr = 420.f;

	ImGui::SetNextWindowSize(ImVec2(800, 600));
	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10.0f, 10.0f));
	ImGui::PushFont(Verdana);
	ImGui::Begin(EX("CWIN Fortnite: Tournament Edition").decrypt(), NULL, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize);

	ImGui::SetCursorPos(ImVec2(40, 40));
	TabButton(EX("Aimbot"), &MenuTab, 0, false);
	ImGui::SetCursorPos(ImVec2(40, 100));
	TabButton(EX("Visuals"), &MenuTab, 6, false);
	ImGui::SetCursorPos(ImVec2(40, 160));
	TabButton(EX("Misc"), &MenuTab, 7, false);
	ImGui::SetCursorPos(ImVec2(10, 504));

	if (MenuTab == 0)
	{
		ImGui::SetCursorPos(ImVec2(220, 36));
		ImGui::BeginChild(("##Tabs2"), ImVec2(-1, 60));
		{
			if (ImGui::Button((("Rifle")), ImVec2(90, 20)))
			{
				VisualTab = 1;
			}ImGui::SameLine();
			if (ImGui::Button((("ShotGun")), ImVec2(90, 20)))
			{
				VisualTab = 2;
			}ImGui::SameLine();
			if (ImGui::Button((("SMG")), ImVec2(90, 20)))
			{
				VisualTab = 3;
			}ImGui::SameLine();
			if (ImGui::Button((("Sniper")), ImVec2(90, 20)))
			{
				VisualTab = 4;
			} ImGui::SameLine();
			ImGui::EndChild();
		}
		if (VisualTab == 1)
		{
			ImGui::SetCursorPos(ImVec2(220, 60));

			ImGui::BeginChild(EX("Aimbot"), ImVec2(385, 450), true);
			TextCentered(EX_("Rifle Setting"));
			ImGui::PushItemWidth(150.f);
			ImGui::Checkbox((EX("Aimbot")), &aimbot::aimbot);
			ImGui::Checkbox((EX("Smooth")), &aimbot::smooth);
			ImGui::Checkbox((EX("Show FOV")), &aimbot::fovcircle);

			ImGui::Text((EX("FOV: ")));
			ImGui::SliderFloat(EX("##fovkrai"), &aimbot::aimfov, 1.f, 700.f, EX("%.2f"));

			ImGui::Text((EX("FOV While ADS: ")));
			ImGui::SliderFloat(EX("##ads"), &aimbot::adsfov, 1.f, 700.f, EX("%.2f"));

			ImGui::Text((EX("Smooth: ")));
			ImGui::SliderFloat(EX("##smoothkrai"), &aimbot::aimspeed, 1.0f, 50.0f, EX("%.2f"));

			ImGui::Text((EX("HipFire Smooth: ")));
			ImGui::SliderFloat(EX("##hipfiresmooth"), &aimbot::hipfire, 1.0f, 20.0f, EX("%.2f"));

			ImGui::Text((EX("Aimbot Distance: ")));
			ImGui::SliderFloat(EX("##aimdistance"), &aimbot::aimdistance, 1.f, 300.0f, EX("%.2f"));

			ImGui::Text((EX("Aim Key: ")));
			HotkeyButton(hotkeys::aimkey, ChangeKey, keystatus);

			ImGui::Text((EX("Hitbox: ")));
			ImGui::Combo((EX("##BONES")), &aimbot::hitbox, Hitbox, IM_ARRAYSIZE(Hitbox));
			ImGui::EndChild();
		}
		if (VisualTab == 2)
		{
			ImGui::SetCursorPos(ImVec2(220, 60));

			ImGui::BeginChild(EX("Aimbot"), ImVec2(385, 450), true);
			TextCentered(EX_("ShotGun Setting"));
			ImGui::PushItemWidth(150.f);

			ImGui::Checkbox((EX("Aimbot")), &aimbot2::aimbot);
			ImGui::Checkbox((EX("Smooth")), &aimbot2::smooth);
			ImGui::Checkbox((EX("Show FOV")), &aimbot2::fovcircle);

			ImGui::Text((EX("FOV: "))); ;
			ImGui::SliderFloat(EX("##fovkrai2"), &aimbot2::aimfov, 1.f, 700.f, EX("%.2f"));

			ImGui::Text((EX("FOV While ADS: ")));
			ImGui::SliderFloat(EX("##ads2"), &aimbot2::adsfov, 1.f, 700.f, EX("%.2f"));

			ImGui::Text((EX("Smooth: ")));
			ImGui::SliderFloat(EX("##smoothkrai2"), &aimbot2::aimspeed, 1.0f, 50.0f, EX("%.2f"));

			ImGui::Text((EX("HipFire Smooth: ")));
			ImGui::SliderFloat(EX("##hipfiresmooth2"), &aimbot2::hipfire, 1.0f, 20.0f, EX("%.2f"));

			ImGui::Text((EX("Aimbot Distance: ")));
			ImGui::SliderFloat(EX("##aimdistance2"), &aimbot2::aimdistance, 1.f, 300.0f, EX("%.2f"));

			ImGui::Text((EX("Aim Key: ")));
			HotkeyButton(hotkeys2::aimkey2, ChangeKey2, keystatus);

			ImGui::Text((EX("Hitbox: ")));
			ImGui::Combo((EX("##BONES")), &aimbot2::hitbox, Hitbox, IM_ARRAYSIZE(Hitbox));

			ImGui::EndChild();
		}
		if (VisualTab == 3)
		{
			ImGui::SetCursorPos(ImVec2(220, 60));

			ImGui::BeginChild(EX("Aimbot"), ImVec2(385, 450), true);
			TextCentered(EX_("SMG Setting"));
			ImGui::PushItemWidth(150.f);

			ImGui::Checkbox((EX("Aimbot")), &aimbot3::aimbot);
			ImGui::Checkbox((EX("Smooth")), &aimbot3::smooth);
			ImGui::Checkbox((EX("Show FOV")), &aimbot3::fovcircle);

			ImGui::Text((EX("FOV: ")));
			ImGui::SliderFloat(EX("##fovkrai3"), &aimbot3::aimfov, 1.f, 700.f, EX("%.2f"));

			ImGui::Text((EX("FOV While ADS: ")));
			ImGui::SliderFloat(EX("##ads3"), &aimbot3::adsfov, 1.f, 700.f, EX("%.2f"));

			ImGui::Text((EX("Smooth: ")));
			ImGui::SliderFloat(EX("##smoothkrai3"), &aimbot3::aimspeed, 1.0f, 50.0f, EX("%.2f"));

			ImGui::Text((EX("HipFire Smooth: ")));
			ImGui::SliderFloat(EX("##hipfiresmooth3"), &aimbot3::hipfire, 1.0f, 20.0f, EX("%.2f"));

			ImGui::Text((EX("Aimbot Distance: ")));
			ImGui::SliderFloat(EX("##aimdistance3"), &aimbot3::aimdistance, 1.f, 300.0f, EX("%.2f"));

			ImGui::Text((EX("Aim Key: ")));
			HotkeyButton(hotkeys3::aimkey3, ChangeKey3, keystatus);

			ImGui::Text((EX("Hitbox: ")));
			ImGui::Combo((EX("##BONES")), &aimbot3::hitbox, Hitbox, IM_ARRAYSIZE(Hitbox));

			ImGui::EndChild();
		}
		if (VisualTab == 4)
		{
			ImGui::SetCursorPos(ImVec2(220, 60));

			ImGui::BeginChild(EX("Aimbot"), ImVec2(385, 450), true);
			TextCentered(EX_("Sniper Setting"));
			ImGui::PushItemWidth(150.f);

			ImGui::Checkbox((EX("Aimbot")), &aimbot5::aimbot);
			ImGui::Checkbox((EX("Smooth")), &aimbot5::smooth);
			ImGui::Checkbox((EX("Show FOV")), &aimbot5::fovcircle);

			ImGui::Text((EX("FOV: ")));
			ImGui::SliderFloat(EX("##fovkrai4"), &aimbot5::aimfov, 1.f, 700.f, EX("%.2f"));

			ImGui::Text((EX("FOV While ADS: ")));
			ImGui::SliderFloat(EX("##ads5"), &aimbot5::adsfov, 1.f, 700.f, EX("%.2f"));

			ImGui::Text((EX("Smooth: ")));
			ImGui::SliderFloat(EX("##smoothkrai4"), &aimbot5::aimspeed, 1.0f, 50.0f, EX("%.2f"));

			ImGui::Text((EX("HipFire Smooth: ")));
			ImGui::SliderFloat(EX("##hipfiresmooth5"), &aimbot5::hipfire, 1.0f, 20.0f, EX("%.2f"));

			ImGui::Text((EX("Aimbot Distance: ")));
			ImGui::SliderFloat(EX("##aimdistance5"), &aimbot5::aimdistance, 1.f, 300.0f, EX("%.2f"));

			ImGui::Text((EX("Aim Key: ")));
			HotkeyButton(hotkeys5::aimkey5, ChangeKey5, keystatus);

			ImGui::Text((EX("Hitbox: ")));
			ImGui::Combo((EX("##BONES4")), &aimbot5::hitbox, Hitbox, IM_ARRAYSIZE(Hitbox));

			ImGui::EndChild();
		}
	}
	else if (MenuTab == 6)
	{
		ImGui::SetCursorPos(ImVec2(220, 36));

		ImGui::BeginChild(EX("ESP"), ImVec2(400, 500), true);
		TextCentered(EX_("ESP"));

		ImGui::PushItemWidth(150.f);

		ImGui::Checkbox((EX("Show Box")), &visuals::box);
		ImGui::SameLine(120.f);
		ImGui::Checkbox((EX("Show Skeleton")), &visuals::skeleton);
		ImGui::Checkbox((EX("Show Lines")), &visuals::lines);
		ImGui::SameLine(120.f);
		ImGui::Checkbox((EX("Outline")), &visuals::outline);
		ImGui::Checkbox((EX("Show Distance")), &visuals::name);
		ImGui::SameLine(150.f);
		ImGui::Checkbox((EX("Show TeamID")), &visuals::teamid);
		ImGui::Checkbox((EX("Weapon Name")), &visuals::weapon);
		ImGui::SameLine(150.f);
		ImGui::Checkbox((EX("Ammo")), &visuals::ammo);

		ImGui::Text((EX("Esp Distance: ")));
		ImGui::SameLine(150.f);
		ImGui::SliderFloat(EX("##espdistance"), &visuals::MaxDistance, 1.0f, 500.0f, EX("%.2f"));

		ImGui::Text((EX("Skeleton Distance: ")));
		ImGui::SameLine(150.f);
		ImGui::SliderFloat(EX("##skeletondistance"), &visuals::MaxSkeletonDrawDistance, 1.0f, 300.0f, EX("%.2f"));

		ImGui::Text((EX("Box Style")));
		ImGui::Combo((EX("##BOXSTYLES")), &visuals::boxMode, boxStyle, IM_ARRAYSIZE(boxStyle));

		ImGui::Text(EX("Lines Style"));
		ImGui::Combo((EX("##LINESSTYLE")), &visuals::lineMode, linesMode, IM_ARRAYSIZE(linesMode));

		ImGui::Checkbox((EX("Items")), &visuals::items);

		ImGui::Checkbox((EX("Common")), &items::Common);
		ImGui::SameLine(150.f);
		ImGui::Checkbox((EX("Green")), &items::UnCommon);
		ImGui::Checkbox((EX("Blue(rare)")), &items::rare);
		ImGui::SameLine(150.f);
		ImGui::Checkbox((EX("Purple(epic)")), &items::purple);
		ImGui::Checkbox((EX("Gold")), &items::gold);
		ImGui::SameLine(150.f);
		ImGui::Checkbox((EX("Mythic")), &items::mythic);

		ImGui::Text((EX("Item Distance: ")));
		ImGui::SliderFloat(EX("##itemdistance"), &visuals::ItemDistance, 1.0f, 100.0f, EX("%.2f"));

		ImGui::EndChild();
	}
	else if (MenuTab == 7)
	{
		ImGui::SetCursorPos(ImVec2(220, 36));

		ImGui::BeginChild(EX("Misc"), ImVec2(400, 500), true);
		TextCentered(EX_("Misc"));

		ImGui::PushItemWidth(100.f);

		ImGui::Text((EX("Visible : ")));
		ImGui::ColorPicker4(EX("##visible"), (float*)&colors::visible, ImGuiColorEditFlags_HDR | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview);

		ImGui::Text((EX("Invisible : ")));
		ImGui::ColorPicker4(EX("##invisible"), (float*)&colors::invisible, ImGuiColorEditFlags_HDR | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview);

		ImGui::Text((EX("FovCircle : ")));
		ImGui::ColorPicker4(EX("##Fov"), (float*)&colors::fov, ImGuiColorEditFlags_HDR | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview);

		ImGui::Text((EX("Config: "))); ImGui::SameLine(80.f); ImGui::Combo((EX("##settsas")), &setting::settsMode, settsName, IM_ARRAYSIZE(settsName));

		if (ImGui::Button(((EX("Save"))), ImVec2(100, 20)))
		{
			if (setting::settsMode == 0)
				Save_Settings((EX("C:\\Default.ini")));
			if (setting::settsMode == 1)
				Save_Settings((EX("C:\\FN-Default1.ini")));
			if (setting::settsMode == 2)
				Save_Settings((EX("C:\\FN-Default2.ini")));
		}

		ImGui::SameLine(150.f);
		if (ImGui::Button(((EX("Load"))), ImVec2(100, 20)))
		{
			if (setting::settsMode == 0)
				Load_Settings((EX("C:\\Default.ini")));
			if (setting::settsMode == 1)
				Save_Settings((EX("C:\\FN-Default1.ini")));
			if (setting::settsMode == 2)
				Save_Settings((EX("C:\\FN-Default2.ini")));
		}

		ImGui::EndChild();
	}
	ImGui::PopFont();
}
static bool menu_key = false;
static auto shortcurts() -> void
{
	if (GetAsyncKeyState(VK_INSERT))
	{
		if (menu_key == false)
		{
			menu_key = true;
		}
		else if (menu_key == true)
		{
			menu_key = false;
		}
		Sleep(200);
	}
}

void render()
{
	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();

	shortcurts();
	if (menu_key)
	{
		menu();
	}
	DrawCallback();

	ImGui::Render();
	ImVec4 clear_color = ImVec4(0., 0., 0., 0.);
	g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, NULL);
	g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, (float*)&clear_color);
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
	g_pSwapChain->Present(1, 0);
}
WPARAM MainLoop()
{
	static RECT old_rc;
	ZeroMemory(&Message, sizeof(MSG));

	while (Message.message != WM_QUIT)
	{
		if (PeekMessage(&Message, MyWnd, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&Message);
			DispatchMessage(&Message);
		}

		ImGuiIO& io = ImGui::GetIO(); (void)io;
		POINT p;
		POINT xy;
		GetCursorPos(&p);
		io.MousePos.x = p.x;
		io.MousePos.y = p.y;

		if (GetAsyncKeyState(VK_LBUTTON)) {
			io.MouseDown[0] = true;
			io.MouseClicked[0] = true;
			io.MouseClickedPos[0].x = io.MousePos.x;
			io.MouseClickedPos[0].x = io.MousePos.y;
		}
		else
			io.MouseDown[0] = false;

		render();
		Sleep(1);
	}

	ImGui_ImplDX11_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();

	CleanupDeviceD3D();
	DestroyWindow(MyWnd);

	return Message.wParam;
}
